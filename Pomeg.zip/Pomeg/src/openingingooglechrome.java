import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class openingingooglechrome {
	
	 private static WebDriver driver;
	 
	 public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "D:\\kavita\\chromedriver.exe");
		 System.out.println("aaaaaaaaaaaaaa");
		 driver = new ChromeDriver();
		 driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/Lesson%205-HTML%20Pages/PopupWin.html");
		
		 
	}
	 
}

package pomexamples.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;

//create testng project
public class PagefactoryFirstAndLastName {

	WebDriver driver;
	
	//step1: Identifying the elements.
	@FindBy (id="txtUserName")
	@CacheLookup
	WebElement uname;
	
	//using how class
	
	@FindBy(how=How.NAME,using="txtLN")
	@CacheLookup
	WebElement ln;
	
	@FindBy(id="rbMale")
	@CacheLookup
	WebElement check;
	
	


	//step2: creating parameterized constructor
	
	public PagefactoryFirstAndLastName(WebDriver driver) {
		super();
		this.driver = driver;
	}

	//creating getter and setter for each files

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public void setUname() {
		uname.sendKeys("KAvita");
	}

	public void setLn() {
		ln .sendKeys("KAvita");
	}
	
	public void setRadio()
	{
		check.click();
		driver.close();
	}
	
}

package pomeg.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;


public class WorkingWithFormOR {

	@Test
	public void testConfig() throws Exception
	{
		//to access property file
		
		File src = new File("./configuration/firstforrepository.property");
		FileInputStream fis = new FileInputStream(src);
		//to read the property file create an object of a property class
		Properties pro=new Properties();
		//to load the property file
		pro.load(fis);
		
		//to fetch the key value from the property file
		WebDriver driver = new FirefoxDriver(); 
		String url=pro.getProperty("url");
		driver.get(url);
		Thread.sleep(2000);
		driver.findElement(By.id(pro.getProperty("userName"))).sendKeys("Capgemini");
		Thread.sleep(2000);
		driver.findElement(By.xpath(pro.getProperty("lastName"))).sendKeys("Technology");
	}
	
	@Test
	public void TextXml() throws Exception
	{
		File src = new File("./configuration/FirstXml.xml");
		FileInputStream fis = new FileInputStream(src);
		SAXReader ssxReader=new SAXReader();
		Document doc=ssxReader.read(fis);
		WebDriver driver = new FirefoxDriver(); 
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		driver.findElement(By.id(doc.selectSingleNode("//details/username").getText())).sendKeys("Kavita");;
		
		
	}
	
}

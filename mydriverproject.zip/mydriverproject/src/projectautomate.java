import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class projectautomate {

	public static void main(String[] args) throws Exception {
		
		WebDriver driver=new FirefoxDriver();
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		
		System.out.println("The title of the webpage is: " + driver.getTitle());
		
		//to check the textbox is enabled
		if(driver.findElement(By.id("txtUserName")).isEnabled())
			System.out.println("Enabled");
		else
			System.out.println("Disabled");
		
		//sending key using id
		driver.findElement(By.id("txtUserName")).sendKeys("Kavita");
		Thread.sleep(1000);
		
		//sending key using name
		driver.findElement(By.name("txtPwd")).sendKeys("kavita");
		Thread.sleep(1000);
		
		//sending key using class
		System.out.println("The password is: " + driver.findElement(By.name("txtPwd")).getAttribute("value"));
		driver.findElement(By.className("Format")).sendKeys("kavita");
		Thread.sleep(1000);
		
		//sending key using css selector
		driver.findElement( By.cssSelector("input#txtFirstName")).sendKeys("Kavita");
		Thread.sleep(1000);
		
		//sending key using xpath
		driver.findElement(By.xpath("//*[@id='DOB']")).sendKeys("19-10-2018");
		Thread.sleep(1000);
		
		//for radio button
		driver.findElement(By.id("rbMale")).click();
			if(driver.findElements(By.name("gender")).get(0).isSelected())
				System.out.println("Male is selected");
			else
				System.out.println("Female is selected");
		Thread.sleep(1000);
		
		//to get text between two static data between tag
		System.out.println("The text between td is: " + driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[1]")).getText());
		Thread.sleep(1000);
		
		//to select values for check box note:For page factory setter copy the select line
		Select drpdown=new Select((WebElement) driver.findElement(By.name("City")));
		drpdown.selectByValue("Chennai");
		drpdown.selectByIndex(2);
		Thread.sleep(1000);
		if(drpdown.isMultiple())
			{
			drpdown.selectByIndex(2);
			System.out.println("Multiple value is seleted");
			}
	   else
			System.out.println("Multiple values not selected");
		Thread.sleep(1000);
		
		//to get the total count of selected element in dropdown
		System.out.println("---------------------------");
		List <WebElement> element=drpdown.getOptions();
		
		int count=0;
		for(int i=0;i<element.size();i++)
		{
			if(element.get(i).isSelected())
				count++;
		}
		System.out.println("The total count of element is: " +count);
		
		//to get the values of the dropdown list
		for(int i=0;i<element.size();i++)
		{
			System.out.println(element.get(i).getText());
		}
		System.out.println("---------------------------");
		
		//for checkbox
		List <WebElement> check=driver.findElements(By.name("chkHobbies"));
		//selection of checkbox
		driver.findElement(By.id("Music")).click();
		driver.findElement(By.id("Reading")).click();
		
		for(WebElement hobbies:check)
			if(hobbies.isSelected())
			System.out.println(hobbies.getAttribute("value"));
		Thread.sleep(1000);
		
		//seleting element by linktext
		driver.findElement(By.linkText("ABC")).click();
		Thread.sleep(1000);
		driver.navigate().back();
		Thread.sleep(1000);
		//selecting elemenyt by partial link
		driver.findElement(By.partialLinkText("A")).click();
		
		driver.quit();
		
	}

}

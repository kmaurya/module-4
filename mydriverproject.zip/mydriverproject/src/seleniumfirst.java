import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class seleniumfirst {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();


  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

@Test
  public void testFirst() throws Exception {
    driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
    
    boolean flag1 = isElementPresent(By.name("txtUName"));
    System.out.println(flag1);
    
    driver.findElement(By.id("txtPassword")).sendKeys("Kavi");
    String pass = driver.findElement(By.id("txtPassword")).getAttribute("value");
    System.out.println(pass);
    
    driver.findElement(By.id("txtUserName")).clear();
    driver.findElement(By.id("txtUserName")).sendKeys("Kavita");
    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    
    String pass1 = driver.findElement(By.id("txtPassword")).getText();
    System.out.println(pass1);
    
    assertTrue(driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Email Registration[\\s\\S]*$"));
    driver.navigate().refresh();
    
    String title = driver.getTitle();
    System.out.println(title + " is the title");
    
    new Select(driver.findElement(By.name("City"))).selectByVisibleText("Mumbai");
    // ERROR: Caught exception [ERROR: Unsupported command [isEditable | id=txtAddress | ]]
  
    driver.findElement(By.id("rbMale")).click();
    
    String checkbox = driver.findElement(By.id("rbMale")).getAttribute("value");
    System.out.println(checkbox);
    
 // Warning: assertTextPresent may require manual changes
   /* driver.findElement(By.id("txtPassword")).clear();
    driver.findElement(By.id("txtPassword")).sendKeys("");
    driver.findElement(By.id("txtPassword")).clear();*/
    driver.findElement(By.id("txtPassword")).sendKeys("abc");
    driver.findElement(By.id("txtConfPassword")).clear();
    driver.findElement(By.id("txtConfPassword")).sendKeys("def");
    assertThat("Passwords do not match", is(not(closeAlertAndGetItsText())));
    System.out.println("${alert} is the error present");
    // ERROR: Caught exception [ERROR: Unsupported command [getTable | css=table.6.0 | ]]
    // ERROR: Caught exception [unknown command []]
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } 
    catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}

package mydriverproject;

import java.util.concurrent.TimeUnit;



import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

public class fluent_wait {
	
	public static void main  (String[] args)throws Exception
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
		driver.findElement(By.name("txtPwd")).sendKeys("kavita");	
		Thread.sleep(1000);
		driver.findElement(By.className("Format")).sendKeys("kavi");
		Thread.sleep(1000);
		
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

				WebElement ele = wait.until(new Function<WebDriver, WebElement>() 
				{
				public WebElement apply(WebDriver driver)
				            {         
				WebElement element = driver.findElement(By.xpath("html/body/h1"));
				String getTextOnPage = element.getText();
				if(getTextOnPage.equals("Email Registration"))
				{
				System.out.println(getTextOnPage);
				return element;
				}                                             
				else   
				{
				System.out.println("FluentWait Failed");
				                        return null;                        
				}
				}

				});
	}

}

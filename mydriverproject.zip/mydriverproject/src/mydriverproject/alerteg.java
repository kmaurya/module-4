package mydriverproject;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class alerteg {


	public static void main(String[] args) throws Exception
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/WorkingWithForms.html");
		driver.findElement(By.name("txtPwd")).sendKeys("kavita");	
		Thread.sleep(1000);
		driver.findElement(By.className("Format")).sendKeys("kavi");
		Thread.sleep(1000);
		/*driver.findElement(By.id("txtUserName")).sendKeys("kavita");
		 System.out.println(driver.switchTo().alert().getText());
		 Thread.sleep(1000);
		 driver.switchTo().alert().accept();
		 Thread.sleep(1000);
		 WebElement element= driver.findElement(By.className("Format"));
		 element.sendKeys(" ");
		 Thread.sleep(1000);*/
		WebDriverWait wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.alertIsPresent());
		String alrt = driver.switchTo().alert().getText();
		System.out.println(alrt);
		
		 driver.quit();
			
	}

}

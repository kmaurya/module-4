package pagefactory.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;

public class PagefactoryClass {

	WebDriver driver;
	
	//Step 1: Identifying the elements
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pfname;
	
	//using how class
	
	@FindBy(how=How.ID,using="bthPayment")
	@CacheLookup
	WebElement pfbutton;
	
	@FindBy(xpath="//*[@id='txtLastName']")
	@CacheLookup
	WebElement pflname;
	
	@FindBy(how=How.NAME,using="Email")
	@CacheLookup
	WebElement pfemail;
	
	@FindBy(css="input[pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement pfmobile;
	
	@FindBy(how=How.NAME,using="city")
	@CacheLookup
	WebElement pfcity;
	
	@FindBy(how=How.NAME,using="state")
	@CacheLookup
	WebElement pfstate;
	
	@FindBy(how=How.NAME,using="persons")
	@CacheLookup
	int pfpersons;
	
	@FindBy(xpath="//*[@id='rooms']")
	@CacheLookup
	WebElement pfrooms;
	
	@FindBy(how=How.ID,using="txtCardHolderName")
	@CacheLookup
	WebElement pfCardHoldername;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement pfdebit;
	
	@FindBy(name="CVV")
	@CacheLookup
	WebElement pfcvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement pfmonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement pfyear;
	
	
	//steps 2: Setter for all above webelemnts


	public void setPfname(String sfname) {
		pfname.sendKeys(sfname);
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	public void setPflname(String slname) {
		pflname.sendKeys(slname);
	}

	public void setPfemail(String semail) {
		pfemail.sendKeys(semail);;
	}

	public void setPfmobile(String smobile) {
		pfmobile.sendKeys(smobile);
	}

	public void setPfcity(String scity) {
		Select drpCity=new Select(pfcity);
		drpCity.selectByVisibleText(scity);
	}

	public void setPfstate(String sstate) {
		Select drpState=new Select(pfcity);
		drpState.selectByVisibleText(sstate);
	}

	public void setPfpersons(int arg1) {
		pfpersons = arg1;
	}

	public void setPfrooms(WebElement pfrooms) {
		this.pfrooms = pfrooms;
	}

	public void setPfCardHoldername(String scardHolder) {
		pfCardHoldername.sendKeys(scardHolder);
	}

	public void setPfdebit(String sdebit) {
		pfdebit.sendKeys(sdebit);;
	}

	public void setPfcvv(String scvv) {
		pfcvv.sendKeys(scvv);;
	}

	public void setPfmonth(String smonth) {
		pfmonth.sendKeys(smonth);;
	}

	public void setPfyear(String syear) {
		pfyear.sendKeys(syear);;
	}

	

	//getters of the above elements
	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getPfname() {
		return pfname;
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public WebElement getPflname() {
		return pflname;
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public WebElement getPfmobile() {
		return pfmobile;
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	public int getPfpersons() {
		return pfpersons;
	}

	public WebElement getPfrooms() {
		return pfrooms;
	}

	public WebElement getPfCardHoldername() {
		return pfCardHoldername;
	}

	public WebElement getPfdebit() {
		return pfdebit;
	}

	public WebElement getPfcvv() {
		return pfcvv;
	}

	public WebElement getPfmonth() {
		return pfmonth;
	}

	public WebElement getPfyear() {
		return pfyear;
	}



	//initating Elements
	
	public PagefactoryClass(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
	
	
	
	
	
}

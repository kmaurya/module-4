package pagefactory.test;

import java.util.concurrent.TimeUnit;

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import pagefactory.pages.PagefactoryClass;

public class PageFactoryClasstest {
  
	
   private WebDriver driver;
   private PagefactoryClass page;
   
   
   @Before
   public void openBrowser()
   {
	   driver=new FirefoxDriver();
	   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   page = new PagefactoryClass(driver);
	   
	   driver.get("");
   }
	
	@Test
  public void chkRegistrationTitle() throws Exception{
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking")) System.out.println("*title*");
		else System.out.println("title not matched");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
  }
	
	
	@Test
	 public void chkRegistration() throws Exception{
		page.setPfname("Neelima");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPflname("pad");	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfemail("nee@gmail.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfmobile("7897654567");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfcity("Pune");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfstate("Maharashtra");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfpersons(7);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfCardHoldername("Neelima");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfdebit("435647859876543");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfcvv("087");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfmonth("6");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfyear("2020");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		page.setPfbutton();
		driver.close();
		driver.navigate().to("");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
  }
	
	//for checking blank firs name field
	@Test
	public void blankFirstName() throws Exception{
		page.setPfname("");
		Thread.sleep(1000);
		page.setPfbutton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("Alert message is: "+alertMessage);
		driver.close();
	}
	
	
	//for checking blank lastname field
	@Test
	public void blankName() throws Exception{
		page.setPfname("Neelima");
		Thread.sleep(1000);
		page.setPflname("");
		page.setPfbutton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("Alert message is: "+alertMessage);
		driver.close();
	}
	
	//for checking blank mobile field
	
	@Test
	public void mobileBlank() throws Exception{
		page.setPfname("Neelimaa");
		Thread.sleep(1000);
		page.setPflname("pad");
		page.setPfmobile("");
		page.setPfbutton();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("Alert message is: "+alertMessage);
		driver.close();
	}
	
	//for inncorrect mobile number
	
	@Test
	public void incorrectMobile() throws Exception
	{
		page.setPfname("Neelimaa");
		Thread.sleep(1000);
		page.setPflname("pad");
		Thread.sleep(1000);
		page.setPfmobile("098764");
		page.setPfbutton();
		Thread.sleep(1000);
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("Alert message is: "+alertMessage);	
		driver.close();
	}
	
	//not selecting from dropdown
	
	@Test
	public void valueNotFromDrop() throws Exception
	{
		page.setPfname("Neelimaa");
		Thread.sleep(1000);
		page.setPflname("pad");
		Thread.sleep(1000);
		page.setPfmobile("7890987656");
		page.setPfcity("Select City");
		page.setPfbutton();
		Thread.sleep(1000);
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("Alert message is: "+alertMessage);	
		driver.close();
	}
	
	
	
}

import static org.junit.Assert.*;

import org.junit.Test;


public class TestCounter {

Counter count=new Counter();
	
	@Test
	public void increment()
	{
		assertTrue(count.increment()==1);
		assertTrue(count.increment()==2);
	}


@Test
public void decrement()
{
	assertTrue(count.increment()==1);
	}
	
	
	}


public class Hello {
 
	public String HelloWorld()
	{
		return "Hello World";
	}
}

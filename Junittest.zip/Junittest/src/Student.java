
public class Student {
	
	int rollNo;
	String firstname;
	String Lastname;
	
	public Student(int rollNo, String firstname, String lastname) {
		super();
		this.rollNo = rollNo;
		this.firstname = firstname;
		Lastname = lastname;
	}

	public int getRollNo() {
		return rollNo;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return Lastname;
	}
	
	
	

}

import static org.junit.Assert.*;

import org.junit.Test;


public class TestHello {

	@Test 
	public void HelloWorld()
	{
		Hello hello=new Hello();
		assertEquals("Hello World",hello.HelloWorld());
		
	}
}
